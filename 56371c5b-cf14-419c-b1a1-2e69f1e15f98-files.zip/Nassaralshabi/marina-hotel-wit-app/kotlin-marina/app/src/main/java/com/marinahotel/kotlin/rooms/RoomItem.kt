package com.marinahotel.kotlin.rooms

data class RoomItem(
    val number: String,
    val status: String,
    val type: String
)
