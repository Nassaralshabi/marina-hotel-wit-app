// Payments management functions
function loadPaymentsSection() {
    const paymentsSection = document.getElementById('paymentsSection');
    paymentsSection.innerHTML = `
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold text-gray-800">إدارة المدفوعات</h2>
            <button onclick="openAddPaymentModal()" class="btn-primary text-white px-6 py-2 rounded-lg">
                <i class="fas fa-plus ml-2"></i>
                إضافة دفعة
            </button>
        </div>
        <div class="bg-white rounded-xl shadow-sm">
            <div class="overflow-x-auto">
                <table class="w-full table-hover">
                    <thead class="bg-gray-50">
                        <tr>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">رقم الدفعة</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">رقم الحجز</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">المبلغ</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">طريقة الدفع</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">التاريخ</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الملاحظات</th>
                            <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase">الإجراءات</th>
                        </tr>
                    </thead>
                    <tbody id="paymentsTable" class="divide-y divide-gray-200">
                        <!-- Data will be populated here -->
                    </tbody>
                </table>
            </div>
        </div>
    `;
    
    loadPayments();
}

function loadPayments() {
    const payments = dataManager.getData('payments');
    const bookings = dataManager.getData('bookings');
    const paymentsTable = document.getElementById('paymentsTable');
    if (!paymentsTable) return;
    
    paymentsTable.innerHTML = '';
    
    payments.forEach(payment => {
        const booking = bookings.find(b => b.booking_id === payment.booking_id);
        const guestName = booking ? booking.guest_name : 'غير معروف';
        
        const row = document.createElement('tr');
        row.innerHTML = `
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${payment.payment_id}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${payment.booking_id} - ${guestName}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatCurrency(payment.amount)}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${payment.payment_method}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${formatDate(payment.payment_date)}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">${payment.notes}</td>
            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <button onclick="editPayment(${payment.payment_id})" class="text-blue-600 hover:text-blue-900 ml-2">
                    <i class="fas fa-edit"></i>
                </button>
                <button onclick="deletePayment(${payment.payment_id})" class="text-red-600 hover:text-red-900">
                    <i class="fas fa-trash"></i>
                </button>
            </td>
        `;
        paymentsTable.appendChild(row);
    });
}

function editPayment(paymentId) {
    const payments = dataManager.getData('payments');
    const payment = payments.find(p => p.payment_id === paymentId);
    if (payment) {
        openPaymentModal(payment);
    }
}

function deletePayment(paymentId) {
    showConfirmation('هل أنت متأكد من حذف هذه الدفعة؟', () => {
        if (dataManager.deleteItem('payments', paymentId)) {
            loadPayments();
            updateStats();
            showNotification('تم حذف الدفعة بنجاح');
        }
    });
}